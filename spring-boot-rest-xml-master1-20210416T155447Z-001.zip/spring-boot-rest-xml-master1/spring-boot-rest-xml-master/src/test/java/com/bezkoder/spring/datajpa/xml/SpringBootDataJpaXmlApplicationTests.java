package com.bezkoder.spring.datajpa.xml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJpaXmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
