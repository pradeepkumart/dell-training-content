package com.bezkoder.spring.datajpa.xml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDataJpaXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpaXmlApplication.class, args);
	}

}
