# Spring Boot Rest XML example – Web service with XML Response

For more detail, please visit:
> [Spring Boot Rest XML example – Web service with XML Response](https://bezkoder.com/spring-boot-rest-xml/)

## Run Spring Boot application
```
mvn spring-boot:run
```
