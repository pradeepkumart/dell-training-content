package com.xyz;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {//REST API
	@RequestMapping("/abcd") //end point
	public String met(){
		return "First Spring Boot REST API";
	}
	
	@RequestMapping("/mnop")
	public String met1(){
		return "First Spring Boot REST API";
	}
	
	@RequestMapping("/pqrs")
	public String met2(){
		return "First Spring Boot REST API";
	}
}
