package com.example8666.demo8666;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan({"com.example8666.demo8666"})
@SpringBootApplication
public class Demo8666Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo8666Application.class, args);
	}

}


