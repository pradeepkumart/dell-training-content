package com.example8666.demo8666;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.xyz"})
public class Config9 {

}
